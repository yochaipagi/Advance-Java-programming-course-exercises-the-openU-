import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

public class Maman13Ex1Controller {

    @FXML
    private RadioButton circleBt;

    @FXML
    private Button clearBt;

    @FXML
    private ColorPicker colorPick;

    @FXML
    private CheckBox fullShapeBt;

    @FXML
    private ToggleGroup g1;

    @FXML
    private RadioButton lineBt;

    @FXML
    private Pane mainPane;

    @FXML
    private Pane myPane;

    @FXML
    private RadioButton rectBt;

    @FXML
    private Button undoBt;
    
    
    private Color myColor;//will save the color
    
    private boolean isFull = false;//flag to know if the shape will be full or not
    
    private double startX , startY , endX , endY; //will store the (x,y) of the shapes
    
    private int shapeFlag = -1;//in case of line it will be 1 , circle = 2 , rectangle = 3;
    private ArrayList<Shape> myShapes = new ArrayList<Shape>();//will keep all the shapes
    

    @FXML
    void clearPressed(ActionEvent event) {
    	myPane.getChildren().clear();
    }


    @FXML
    void undoPressed(ActionEvent event) { 
    	if(myShapes.size()>0) {
    		myPane.getChildren().remove(myPane.getChildren().size()-1);//when we want to undo we will remove the last shape in 
    		myShapes.remove(0);//and delete it from the list
    	}
    	else {
    		System.out.println("no more shapes to delete");
    	}
    }
    
    @FXML
    void fullPressed(ActionEvent event) {
    	isFull = !isFull;
    }

    @FXML
    void linePressed(ActionEvent event) {
    	shapeFlag = 1;
    }
    
    @FXML
    void circlePressed(ActionEvent event) {
    	
    	shapeFlag = 2;
    }

    @FXML
    void rectPressed(ActionEvent event) {
    	shapeFlag = 3;
    }
    


    @FXML
    void paneClicked(MouseEvent event) {
    	clearXY();
    	startX = event.getX();
    	startY = event.getY();
    }

    @FXML
    void paneRelesed(MouseEvent event) {
    	endX = event.getX();
    	endY = event.getY();
    	myColor = colorPick.getValue();//store the color value
    	switch(shapeFlag) {
    	case 1:
    		Line newLine = new Line(startX, startY, endX, endY);
    		newLine.setStroke(myColor);
    		myPane.getChildren().add(newLine);
			myShapes.add(newLine);//nevertheless we will save the shape to the list
    		break;

    	case 2:
    		Circle newCircle = new Circle(startX,startY,distance(startX,endX, startY, endY) , myColor);//crate new circle in the centered in begin position 
    		if(isFull) {//if the user want a full shape
				myPane.getChildren().add(newCircle);
			}
			else {//other we change the color of the fill
				newCircle.setFill(Color.TRANSPARENT);
				newCircle.setStroke(myColor);
				myPane.getChildren().add(newCircle);
			}
			myShapes.add(newCircle);//nevertheless we will save the shape to the list
    		break;
    	case 3:
    		Rectangle myRect = new Rectangle(Math.abs(endX-startX),Math.abs(endY-startY),myColor);
    		//now we going to relocate the rect from top to bottom
    		if(startX<=endX&&startY<=endY) {
    			myRect.relocate(startX, startY);
    		}
    		else if(startX<endX&&startY>endY) {
    			myRect.relocate(startX, endY);
    		}
    		else if(startX>endX&&startY>endY) {
    			myRect.relocate(endX, endY);
    		}
    		else if(startX>endX&&startY<endY) {
    			myRect.relocate(endX, startY);
    		}
    		if(isFull) {
    			myPane.getChildren().add(myRect);
    		}
    		else {
    			myRect.setFill(Color.TRANSPARENT);
				myRect.setStroke(myColor);
    			myPane.getChildren().add(myRect);
    		}
			myShapes.add(myRect);//nevertheless we will save the shape to the list
    		break;
    	}
    }
    //will return the distance
    private double distance(double x1 ,double x2 ,double y1 ,double y2) {
    	return Math.sqrt(Math.pow(x2-x1, 2) + Math.pow(y2-y1, 2));
    }
 
    private void clearXY(){//clear the (x,y) before new painting
    	startX = -1;
    	startY = -1;
    	endX = -1;
    	endY = -1;
    }
}
