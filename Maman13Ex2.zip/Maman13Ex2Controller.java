
import javax.swing.JOptionPane;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class Maman13Ex2Controller {

    @FXML
    private Button b1;

    @FXML
    private Button b2;

    @FXML
    private Button b3;

    @FXML
    private Button b4;

    @FXML
    private Button b5;

    @FXML
    private Button b6;

    @FXML
    private Button b7;

    @FXML
    private Button clearBt;
    @FXML
    private GridPane myGrid;
    
    @FXML
    private Pane myPane;
    
    private final int ROW_NUM = 6;
    private final int COL_NUM = 7;
    
    private final double CIRCLE_SIZE = 17;//define the circle size
    private boolean colorFlag = false;//will be the flag to know which player turn it is to define the color
    private double COL_SIZE = 10;
	private final int BLUE_FLAG = 1;//the blue flag for the array
	private final int RED_FLAG = 2;//the red flag
	private int [][] board = new int[ROW_NUM][COL_NUM];//will keep the position of players discs this array will help simplify the logic instead of using grid mathod
    
    @FXML
    void b1Pressed(ActionEvent event) {
    	if(board[0][0]!=0) {
    		JOptionPane.showInternalMessageDialog(null, "this column is full try another one");
    		b1.setDisable(true);
    	}
    	else {
    		addDisc(0);
    		colorFlag = !colorFlag;
    	}
    }

    @FXML
    void b2Pressed(ActionEvent event) {
    	if(board[0][1]!=0) {
    		JOptionPane.showInternalMessageDialog(null, "this column is full try another one");
    		b2.setDisable(true);
    	}
    	else {
    		addDisc(1);
    		colorFlag = !colorFlag;
    	}
    }

    @FXML
    void b3Pressed(ActionEvent event) {
    	if(board[0][2]!=0) {
    		JOptionPane.showInternalMessageDialog(null, "this column is full try another one");
    		b3.setDisable(true);
    	}
    	else {
    		addDisc(2);
    		colorFlag = !colorFlag;
    	}
    }

    @FXML
    void b4Pressed(ActionEvent event) {
    	if(board[0][3]!=0) {
    		JOptionPane.showInternalMessageDialog(null, "this column is full try another one");
    		b4.setDisable(true);
    	}
    	else {
    		addDisc(3);
    		colorFlag = !colorFlag;
    	}
    }

    @FXML
    void b5Pressed(ActionEvent event) {
    	if(board[0][4]!=0) {
    		JOptionPane.showInternalMessageDialog(null, "this column is full try another one");
    		b5.setDisable(true);
    	}
    	else {
    		addDisc(4);
    		colorFlag = !colorFlag;
    	}
    }

    @FXML
    void b6Pressed(ActionEvent event) {
    	if(board[0][5]!=0) {
    		JOptionPane.showInternalMessageDialog(null, "this column is full try another one");
    		b6.setDisable(true);
    	}
    	else {
    		addDisc(5);
    		colorFlag = !colorFlag;
    	}
    }

    @FXML
    void b7Pressed(ActionEvent event) {
    	if(board[0][6]!=0) {
    		JOptionPane.showInternalMessageDialog(null, "this column is full try another one");
    		b7.setDisable(true);
    	}
    	else {
    		addDisc(6);
    		colorFlag = !colorFlag;
    	}
    }

    @FXML
    void clearPressed(ActionEvent event) {
    	//we will iterate throw the grid and delete all the no null indexes and clear the board
    	for(int i = ROW_NUM-1 ; i>=0 ; i--) {
    		for(int j = 0 ; j<COL_NUM ; j++) {
    			board[i][j]= 0;//put 0 in all the board 
    			Node tempNode = getNodeFromGridPane(myGrid, j, i);//this is the current index Node
    			if(tempNode!=null) {
    				myGrid.getChildren().remove(tempNode);
    			}
    		}
    	}
    	colorFlag = false;//first turn in the new game will still be red
    	endGame(false);
    }
    //access to specific node in the grid
    private Node getNodeFromGridPane(GridPane myGrid , int col , int row) {
    	ObservableList<Node> child = myGrid.getChildren();
    	for(Node node: child) {
    		Integer colIndex = GridPane.getColumnIndex(node);
    		Integer rowIndex = GridPane.getRowIndex(node);
    		
    		if(colIndex == null) {
    			colIndex = -1;
    		}
    		if(rowIndex == null) {
    			rowIndex = -1;
    		}
    		if(colIndex == col&&rowIndex == row) {
    			return node;
    		}
    	}
    	return null;
    }
    //check if we have a strike in right line
    private int checkRight(int colNum , int row , String str) {
    	//check right
    	int right=0;
    	if(str.equals("red")) {//we have a redd turn
    		for(int colIndex = colNum+1; colIndex<COL_NUM ; colIndex++){
    			if(board[row][colIndex] ==  RED_FLAG) {
    				right+=1;
    			}
    			else {
    				return right;//no need to keep checking for right strike
    			}
    			
    		}
    	}
    	else {//we have a blue turn
    		for(int colIndex = colNum+1; colIndex<COL_NUM ; colIndex++){
    			
    			if(board[row][colIndex] ==  BLUE_FLAG) {
    				right+=1;
    			}
    			else {
    				return right;//no need to keep checking for right strike
    			}
    		}
    	}
    	System.out.println(right +" the right falg now is ");
    	return right;
    }
    //check if we have a strike in left line
    private int checkLeft(int colNum , int row , String str) {
    	//check left
    	int left=0;
    	if(str.equals("red")) {//we have a redd turn
    		for(int colIndex = colNum-1; colIndex>=0 ; colIndex--){
    			if(board[row][colIndex] ==  RED_FLAG) {
    				left+=1;
    			}
    			else {
    				return left;//no need to keep checking for right strike
    			}
    			
    		}
    	}
    	else {//we have a blue turn
    		for(int colIndex = colNum-1; colIndex>0 ; colIndex--){
    			
    			if(board[row][colIndex] ==  BLUE_FLAG) {
    				left+=1;
    			}
    			else {
    				return left;//no need to keep checking for right strike
    			}
    		}
    	}
    	return left;
    }
    //check if we have a strike to down direction
    private int checkDown(int colNum , int row , String str) {
    	//check left
    	int down=0;
    	if(str.equals("red")) {//we have a red turn
    		for(int rowIndex = row+1; rowIndex<ROW_NUM ; rowIndex++){
    			if(board[rowIndex][colNum] ==  RED_FLAG) {
    				down+=1;
    			}
    			else {
    				return down;//no need to keep checking for right strike
    			}	
    		}
    	}
    	else {//we have a blue turn
    		for(int rowIndex = row+1; rowIndex<ROW_NUM ; rowIndex++) {
    			if(board[rowIndex][colNum] ==  BLUE_FLAG) {
    				down+=1;
    			}
    			else {
    				return down;//no need to keep checking for right strike
    			}
    		}
    	}
    	return down;
    }

    private int checkDiagToDownRight(int colNum , int row , String str) {
    	//check left
    	int diag=0;
    	int indexToCheck = colNum+row;
    	if(str.equals("red")) {//we have a red turn
    		//we gonna move in each iteration to bottom right index
    		for(int rowIndex = row+1; rowIndex<ROW_NUM ; rowIndex++){
    			for(int colIndex = colNum+1 ; colIndex<COL_NUM ; colIndex++){
    				//every time we in a "good" index (colnum+row-indexToCheck = 2) we update the index to check
    				if((Math.abs((colIndex + rowIndex)-indexToCheck))==2){
    					indexToCheck =colIndex + rowIndex; 
    					if(board[rowIndex][colIndex] ==  RED_FLAG) {
    						diag+=1;
    						colIndex = COL_NUM;//we need to go to next row and stop checking the columns
    					}
    					else {
    						return diag;//no need to keep checking for right strike
    					}
    				}
    			}
    		}
    	}
    	else {//we have a blue turn
    		for(int rowIndex = row+1; rowIndex<ROW_NUM ; rowIndex++){
    			for(int colIndex = colNum+1 ; colIndex<COL_NUM ; colIndex++) {
    				//every time we in a "good" index (colnum+row-indexToCheck = 2) we update the index to check
    				if((Math.abs((colIndex + rowIndex)-indexToCheck))==2){
    					indexToCheck =colIndex + rowIndex; 
    					if(board[rowIndex][colIndex] ==  BLUE_FLAG) {
    						diag+=1;
    						colIndex = COL_NUM;//we need to go to next row and stop checking the columns
    					}
    					else {
    						return diag;//no need to keep checking for right strike
    					}
    				}
    			}
    		}
    	}
    	return diag;
    }
    private int checkDiagToUpLeft(int colNum , int row , String str) {
    	//check up left
    	int diag=0;
    	int indexToCheck = colNum+row;
    	if(str.equals("red")) {//we have a red turn
    		//we gonna move in each iteration to bottom right index
    		for(int rowIndex = row-1; rowIndex>=0 ; rowIndex--){
    			for(int colIndex = colNum-1 ; colIndex>=0 ; colIndex--) {
    				//every time we in a "good" index (colnum+row-indexToCheck = 2) we update the index to check
    				if((Math.abs((colIndex + rowIndex)-indexToCheck))==2){
    					indexToCheck =colIndex + rowIndex; 
    					if(board[rowIndex][colIndex] ==  RED_FLAG) {
    						diag+=1;
    						colIndex = -1;//we need to go to next row and stop checking the columns
    					}
    					else {
    						return diag;//no need to keep checking for right strike
    					}
    				}
    			}
    		}
    	}
    	else {//we have a blue turn
    		for(int rowIndex = row-1; rowIndex>=0 ; rowIndex--){
    			for(int colIndex = colNum-1 ; colIndex>=0 ; colIndex--) {
    				//every time we in a "good" index (colnum+row-indexToCheck = 2) we update the index to check
    				if((Math.abs((colIndex + rowIndex)-indexToCheck))==2){
    					indexToCheck =colIndex + rowIndex; 
    					if(board[rowIndex][colIndex] ==  BLUE_FLAG) {
    						diag+=1;
    						colIndex = -1;//we need to go to next row and stop checking the columns
    					}
    					else {
    						return diag;//no need to keep checking for right strike
    					}
    				}
    			}
    		}
    	}
    	return diag;
    }
    //to make the code more readable this will add the diag up left to diag down right
    private int checkDiagUpLeftToDownRight(int colNum , int Row , String str) {
    	return checkDiagToUpLeft(colNum, Row, str)+checkDiagToDownRight(colNum, Row, str);
    }
    
    
    //to make the code more readable this will add the diag up right to diag down left
    private int checkDiagUpRightToDownLetf(int colNum , int Row , String str) {
    	return checkDiagToUpRight(colNum, Row, str)+checkDiagToDownLeft(colNum, Row, str);
    }
    private int checkDiagToDownLeft(int colNum , int row , String str) {
    	//check left
    	int diag=0;
    	int indexToCheck = colNum+row;
    	if(str.equals("red")) {//we have a red turn
    		//we gonna move in each iteration to bottom left index
    		for(int rowIndex = row+1; rowIndex<ROW_NUM ; rowIndex++){
    			for(int colIndex = colNum-1 ; colIndex>=0 ; colIndex--) {
    				//we need to check only indexes that the row +column = colNum+row
    				if(colIndex + rowIndex == indexToCheck) {
            			if(board[rowIndex][colIndex] ==  RED_FLAG) {
            				diag+=1;
            			}
            			else {
            				return diag;//no need to keep checking for right strike
            			}
    				}
    			}
    		}
    	}
    	else {//we have a blue turn
    		for(int rowIndex = row+1; rowIndex<ROW_NUM ; rowIndex++){
    			for(int colIndex = colNum-1 ; colIndex>=0 ; colIndex--) {
    				//we need to check only indexes that the row +column = colNum+row
    				if(colIndex + rowIndex == indexToCheck) {
            			if(board[rowIndex][colIndex] ==  BLUE_FLAG) {
            				diag+=1;
            			}
            			else {
            				return diag;//no need to keep checking for right strike
            			}
    				}

    			}
    		}
    	}
    	return diag;
    }
    private int checkDiagToUpRight(int colNum , int row , String str) {
    	//check left
    	int diag=0;
    	int indexToCheck = colNum+row;
    	if(str.equals("red")) {//we have a red turn
    		//we gonna move in each iteration to up right index
    		for(int rowIndex = row-1; rowIndex>=0 ; rowIndex--){
    			for(int colIndex = colNum+1 ; colIndex<COL_NUM ; colIndex++){
    				//we need to check only indexes that the row +column = colNum+row
    				if(colIndex + rowIndex == indexToCheck) { 
    					if(board[rowIndex][colIndex] ==  RED_FLAG) {
    						diag+=1;
    					}
    					else {
    						return diag;//no need to keep checking for right strike
    					}
    				}
    			}
    		}
    	}
    	else {//we have a blue turn
    		for(int rowIndex = row-1; rowIndex>=0 ; rowIndex--){
    			for(int colIndex = colNum+1 ; colIndex<COL_NUM ; colIndex++){
    				//we need to check only indexes that the row +column = colNum+row
    				if(colIndex + rowIndex == indexToCheck) { 
    					if(board[rowIndex][colIndex] ==  BLUE_FLAG) {
    						diag+=1;
    					}
    					else {
    						return diag;//no need to keep checking for right strike
    					}
    				}
    			}
    		}
    	}
    	return diag;
    }
    //each turn we will check if we have a strike in all directions
    private void checkForWinner(int colNum,int row , String str) {
    	if(checkRight(colNum , row , str)==3) {;//if we have a strike the method return 3
    		JOptionPane.showInternalMessageDialog(null, "the "+str+" player have won!");
    		endGame(true);
    	}
    	if(checkLeft(colNum , row , str)==3) {;//if we have a strike the method return 3
    		JOptionPane.showInternalMessageDialog(null, "the "+str+" player have won!");
    		endGame(true);
    	}
    	if(checkDown(colNum , row , str)==3) {;//if we have a strike the method return 3
    		JOptionPane.showInternalMessageDialog(null, "the "+str+" player have won!");
    		endGame(true);
    	}
    	if(checkDiagUpLeftToDownRight(colNum,row,str) == 3) {;//in order to check diag strike we will add the diag down right + diag up left if 3 we have a strike
    		JOptionPane.showInternalMessageDialog(null, "the "+str+" player have won!");
    		endGame(true);
    	}
    	if(checkDiagUpRightToDownLetf(colNum, row, str)==3) {//in order to check diag strike we will add the diag up right + diag down left if 3 we have a strike
    		JOptionPane.showInternalMessageDialog(null, "the "+str+" player have won!");
    	    endGame(true);
    	}
   	//there is no need to check a strike in upward direction all the vertical strikes begin from the bottom
    }
    //make all the buttoms disabled if the game is over or enabled when cleared
    private void endGame(boolean flag){
    	b1.setDisable(flag);
    	b2.setDisable(flag);
    	b3.setDisable(flag);
    	b4.setDisable(flag);
    	b5.setDisable(flag);
    	b6.setDisable(flag);
    	b7.setDisable(flag);
    	
    }
    private void addDisc (int colNum) {
    	int row;//will be the row to insert the disc
    	String str = "red";//red will be the default
    	for(row = ROW_NUM-1 ; row>=0 ; row--){//we will find the empty index in the column
    		Node tempNode = getNodeFromGridPane(myGrid,colNum,row);
    			if(tempNode == null) {//this is the place to put the disc
    				int midX = (int) (colNum*COL_SIZE+COL_SIZE/2);//will locate the disc in the position
    				int midY = (int) (row*COL_SIZE+COL_SIZE/2);//will locate the disc in the position
    				Circle disc = new Circle(midX,midY,CIRCLE_SIZE,Color.RED);
    				if(colorFlag) {
    					disc.setFill(Color.BLUE);
    					str = "blue";
    				}
    				disc.setUserData(str);//insert the color to the disc object
    				myGrid.add(disc, colNum, row);
    				GridPane.setRowIndex(disc, row);
    				GridPane.setColumnIndex(disc, colNum);
    				//initialize the board with flags as the discs on the actual game board
    				if(str.equals("blue")) {
    					board[row][colNum] = BLUE_FLAG;
    				}
    				else {
    					board[row][colNum] = RED_FLAG;
    				}
    				try {
    					checkForWinner(colNum , row , str);
    				}
    				catch (Exception e) {
    					System.out.println("cant be a winner yet");
    				}
    				break;
    		}
    	}
    }

}
