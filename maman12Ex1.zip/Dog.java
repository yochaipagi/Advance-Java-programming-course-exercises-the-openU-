
public class Dog extends Mamal {
	private int tailLong;
	private Owner owner;
	
	public Dog(int age , String name , String color , int tailLong) {
		super(age , name , color);
		this.tailLong = tailLong;
		this.owner = new Owner();//crate an  empty owner
		
	}
	public Dog(int age , String name , String color , int tailLong , String ownerName , String ownerPhone) {
		super(age , name , color);
		this.tailLong = tailLong;
		this.owner = new Owner(ownerName , ownerPhone);//crate an owner
		
	}
	public String getOwnerName() {
		return this.owner.getName();
	}
	public void setOwnerName(String name) {
		this.owner.setName(name);
	}
	public String getOwnerPhone() {
		return this.owner.getPhoneNum();
	}
	public void setOwnerPhone(String phone) {
		this.owner.setPhone(phone);
	}

	@Override
	public void move() {
		System.out.println("move like a Dog");
	}

	@Override
	public void eat() {
		System.out.println("eat like a dog");
		
	}

	@Override
	public void sleep() {
		System.out.println("sleep like a Dog");
		
	}
	
	public int getTail() {
		return this.tailLong;
	}
	public void setTail(int tailLong) {
		this.tailLong = tailLong;
	}
	
	
	public Dog clone() {
		Dog temp = new Dog(this.getAge() , this.getColor(), this.getName() , this.tailLong , this.owner.getName() , this.owner.getPhoneNum());//clone the animal with new param
		return temp;
	}
	
	public boolean equals(Dog other) { //i am using object in order to use the dynamic binding
	if(super.equals(other) && this.tailLong == other.getTail()) {
		return true;
	}
	else return false;
	}
	
	
	public String toString() {
		return "i am a Dog and " + super.toString() + "my tail is " + this.tailLong + " long" + "my owner is " + this.owner.getName();
	}

}
