
public class Cat extends Mamal {
	private int tailLong;
	private Owner owner;
	
	public Cat(int age , String name , String color , int tailLong) {
		super(age , name , color);
		this.tailLong = tailLong;
		this.owner = new Owner();//crate an  empty owner
		
	}
	public Cat(int age , String name , String color , int tailLong , String ownerName , String ownerPhone) {
		super(age , name , color);
		this.tailLong = tailLong;
		this.owner = new Owner(ownerName , ownerPhone);//crate an owner
		
	}
	
	public String getOwnerName() {
		return this.owner.getName();
	}
	public void setOwnerName(String name) {
		this.owner.setName(name);
	}
	public String getOwnerPhone() {
		return this.owner.getPhoneNum();
	}
	public void setOwnerPhone(String phone) {
		this.owner.setPhone(phone);
	}

	@Override
	public void move() {
		System.out.println("doing my cat walk");
		
	}

	@Override
	public void eat() {
		System.out.println("eating lika a cat");		
	}

	@Override
	public void sleep() {
		System.out.println("sleeping all day long");		
	}
	
	public int getTail() {
		return this.tailLong;
	}
	public void setTail(int tailLong) {
		this.tailLong = tailLong;
	}
	
	public Cat clone() {
		Cat temp = new Cat(this.getAge() , this.getName() , this.getColor(), this.tailLong , this.owner.getName() , this.owner.getPhoneNum());//clone the animal with new param
		return temp;
	}
	
	public boolean equals(Cat other) { //i am using object in order to use the dynamic binding
	if(super.equals(other) && this.tailLong == other.getTail()) {
		return true;
	}
	else return false;
	}
	public String toString() {
		return " i am a cat and " + super.toString() + " my tail is " + this.tailLong + " long" + "my owner is " + this.owner.getName();
	}
}
