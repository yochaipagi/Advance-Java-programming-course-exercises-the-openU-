
public class Falcon extends Birds{
	private int wingSpan;
	
	public Falcon(int age , String name , String color , int wingSpan) {
		super(age , name , color);
		this.wingSpan = wingSpan;
		
	}
	
	public int getWing() {
		return this.wingSpan;
	}
	public void setWing(int wingSpan) {
		this.wingSpan = wingSpan;
	}

	@Override
	public void fly() {
		System.out.println("flying");
	}

	@Override
	public void eat() {
		System.out.println("going to fetch food");		
	}

	@Override
	public void sleep() {
		System.out.println("falcon sleep");		
	}
	
	
	public Falcon clone() {
		Falcon temp = new Falcon(this.getAge() , this.getColor(), this.getName() , this.wingSpan);//clone the animal with new param
		return temp;
	}
	
	public boolean equals(Falcon other) { //i am using object in order to use the dynamic binding
	if(super.equals(other) && this.wingSpan == other.getWing()) {
		return true;
	}
	else return false;
	}
	
	public String toString() {
		return  "i am a falcon and " + super.toString() + " my wing span is " + this.wingSpan;
	}

}
