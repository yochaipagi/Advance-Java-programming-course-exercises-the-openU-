
public abstract class Fishes extends Animal {
	
	public Fishes(int age , String name , String color) {
		super(age , name , color);
		
	}
	
	public abstract void swim();

	public boolean equals(Animal other) {
		return super.equals(other);
	}
	public String toString() {
		return "i am  fish and " + super.toString();
	}

}
