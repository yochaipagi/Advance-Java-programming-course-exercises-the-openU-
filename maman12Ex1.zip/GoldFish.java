
public class GoldFish extends Fishes {

	private int fishFin;
	private Owner owner;
	
	public GoldFish(int age , String name , String color , int fishFin) {
		super(age , name , color);
		this.fishFin = fishFin;
		owner = new Owner();//crate an empty owner;
	}
	
	public GoldFish(int age , String name , String color , int fishFin , String ownerName , String ownerPhone) {
		super(age , name , color);
		this.fishFin = fishFin;
		owner = new Owner(ownerName , ownerPhone);//crate an owner
	}
	
	public int getFin() {
		return this.fishFin;
	}
	public void setFin(int fin) {
		this.fishFin = fin;
	}
	public String getOwnerName() {
		return this.owner.getName();
	}
	public void setOwnerName(String name) {
		this.owner.setName(name);
	}
	public String getOwnerPhone() {
		return this.owner.getPhoneNum();
	}
	public void setOwnerPhone(String phone) {
		this.owner.setPhone(phone);
	}

	@Override
	public void swim() {
		System.out.println("swimming");
		
	}

	@Override
	public void eat() {
		System.out.println("fish eating");		
	}

	@Override
	public void sleep() {
		System.out.println("i never sleep");		
	}
	
	public GoldFish clone() {
		GoldFish temp = new GoldFish(this.getAge() , this.getColor(), this.getName() , this.fishFin , this.owner.getName() , this.owner.getPhoneNum());//clone the animal with new param
		return temp;
	}
	
	public boolean equals(GoldFish other) { //i am using object in order to use the dynamic binding
	if(super.equals(other) && this.fishFin == other.getFin()) {
		return true;
	}
	else return false;
	}
	
	public String toString() {
		return  "i am a gold fish and " + super.toString() + "my fish fin is " + this.fishFin + " long" + "my owner is " + this.owner.getName();
	}


}
