
public abstract class Mamal extends Animal {
	
	public Mamal(int age , String name , String color) {
		super(age , name , color);
		
	}
	public abstract void move();
	
	public boolean equals(Animal other) {
		return super.equals(other);
	}
	
	public String toString() {
		return "i am  mamal and " + super.toString();
	}
}
