
public abstract class Birds extends Animal {
	
	
	public Birds(int age , String name , String color) {
		super(age , name , color);
		
	}
	
	public abstract void fly();

	public boolean equals(Animal other) {
		return super.equals(other);
	}
	public String toString() {
		return "i am  bird and " + super.toString();
	}

}
