
public abstract class Animal {
	private int age;
	private String name;
	private String color;
	
	public Animal(int age , String name , String color) {
		this.age = age;
		this.name = name;
		this.color = color;
	}
	
	public abstract void eat();
	public abstract void sleep();
	
	public String getName() {
		return this.name;
	}
	public int getAge() {
		return this.age;
	}
	public String getColor(){
		return this.color;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	public boolean equals(Animal other) {
		if(this.age == other.getAge() && this.color.equals(other.getColor())&& this.name.equals(other.getName())) {
			return true;
		}
		else return false;
	}
	
	public String toString() {
		return "my name is " + this.name + " my age is " + this.age + " and my color is " + this.color;
	}
	

}
