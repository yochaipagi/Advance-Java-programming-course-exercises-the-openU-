import java.util.ArrayList; // import the ArrayList class

public class Maman11Main {

	public static void main(String[] args) {
		ArrayList<Animal> petHouse = new ArrayList<Animal>();
		//now we gonna insert some different pets
		petHouse.add(new Cat( 2 , "shimmy" , "yellow", 12 , "matan" , "0521112233"));
		petHouse.add(new Dog( 4 , "bar" , "blue" , 18 , "yossy" , "0522222233"));
		petHouse.add(new GoldFish( 1 , "aladin" , "gold", 3 , "yoav" , "0541784536"));
		petHouse.add(new Falcon( 22 , "bob" , "brown", 80));
		for(int i = 0 ; i<petHouse.size() ; i++) {
			test(petHouse.get(i));//all the tests are in the static method
		}
		//now we going to check the clone method
		Animal newCat = ((Cat) petHouse.get(0)).clone();//clone new cat
		System.out.println(newCat.toString());//the clone is good
		newCat.setAge(42);//set new age
		((Cat)newCat).setOwnerName("ofek");//set new owner name
		System.out.println(newCat.toString());
		System.out.println(petHouse.get(0).toString());//original animal doesn't changed
		//check the Falcon clone method
		Animal newFalcon = ((Falcon) petHouse.get(3)).clone();//clone new Falcon
		System.out.println(newFalcon.toString());//the clone is good
		newFalcon.setAge(78);//set new age
		System.out.println(newFalcon.toString());
		System.out.println(petHouse.get(3).toString());//original animal doesn't changed
	}
	
	//this method demonstrate all the printing 
	public static void test(Animal other) {
		System.out.println(other.getName());
		other.sleep();
		other.eat();
		if(other instanceof Falcon) {
			((Falcon) other).fly();
		}
		if(other instanceof GoldFish) {
			((GoldFish) other).swim();
			System.out.println(((GoldFish) other).getOwnerName());
		}
		if(other instanceof Cat) {
			((Cat) other).move();
			System.out.println(((Cat) other).getOwnerName());
		}
		if(other instanceof Dog) { 
			((Dog) other).move();
			System.out.println(((Dog) other).getOwnerName());
		}
	}

}
