//define an animal owner
public class Owner {
	private String name;
	private String phoneNum;//i think that phone number will be better as a string

	public Owner() {
		this.name = "";
		this.phoneNum = "";
	}
	public Owner(String name , String phone) {
		this.name = name;
		this.phoneNum = phone;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return this.name;
	}
	public void setPhone(String phone) {
		this.name = phone;
	}
	public String getPhoneNum() {
		return this.phoneNum;
	}
	
	public String toString() {
		return "name:"+this.name + " phone number:" +this.phoneNum;
	}
	
}
