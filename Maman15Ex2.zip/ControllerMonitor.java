//Synchronize all the process not to start before finished
public class ControllerMonitor {
    private final int numOfProcesses; // num of process that now running
    private final int numOfRounds; // number of rounds we need to do
    private int currentRound; 
    private int numOfFinished; // number of processes that finished current round
//Create an instance of the controller synchronize the execution of the with the amount of process and num of round from the user
    public ControllerMonitor(int processesAmount, int roundsAmount) {
        this.numOfProcesses = processesAmount;
        this.numOfRounds = roundsAmount;
        this.currentRound = 1;
        this.numOfFinished = 0;
    }
// Wait until we finished the previous round , Return false if all rounds are completed
    public synchronized boolean waitForNextRound(int finishedRound) {
    	boolean finishAllRoundFlag = false;//will be the return value if we finished akk the rounds
        // Stop waiting when the current round number is greater then the finished number.
        while (currentRound <= finishedRound) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        finishAllRoundFlag = currentRound <= numOfRounds;// true if we finished all the rounds
        return finishAllRoundFlag;
    }
//Notify the controller a process has finished its round
    public synchronized void processFinishNotify() {
        numOfFinished++;
        notifyAll(); // To wake the controller monitor when it is waiting for all the processes to finish their round
    }
//Wait until all the processes have finished their round to start printing the current round
    public synchronized void fullRoundPrintWait() {
        while (numOfProcesses > numOfFinished) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
//Notify the controller that the printing current round has done to be able to start the next round.
    public synchronized void finishPrintNotify() {
        currentRound++;
        numOfFinished = 0;
        notifyAll(); // To wake the monitor for the start of the next round.
    }
}

