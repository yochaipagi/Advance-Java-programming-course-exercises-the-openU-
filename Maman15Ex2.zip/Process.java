//represent one process in the program
//each process have a managing ControllerMonitor , left neighbor , right neighbor , process value and number of rounds he already did
//Uses a monitor for synchronization of the rounds
public class Process extends Thread {
    private final ControllerMonitor controllerMonitor; // Monitor for synchronization of each round
    private int processVal;
    private int finishedRound; // The number of rounds this process has finished already
    private Process leftNeighbor;// the left neighbor
    private Process rightNeighbor;//the right neighbor
    private boolean leftChecked; //  flag for if we already check this neighbor
    private boolean rightChecked; // flag for if we already check this neighbor

    //create a process with a controller monitor 
    public Process(ControllerMonitor monitor, int value) {
        this.controllerMonitor = monitor;
        this.processVal = value;
        this.leftNeighbor = null;
        this.rightNeighbor = null;
        this.finishedRound = 0;
        this.leftChecked = false;
        this.rightChecked = false;
    }
    //sets the neighbors before we start the threads
    public void setNeighbors(Process leftProcess, Process rightProcess) {
        this.leftNeighbor = leftProcess;
        this.rightNeighbor = rightProcess;
    }
    //run the thread each round the thread checks his neighbors and update its value if needed
    @Override
    public void run() {
        super.run();
        int chengeValue = 0;//will be the number to add to the process
        // we will throw exception if process have no neighbors
        if (this.rightNeighbor == null || this.leftNeighbor == null) {
            throw new RuntimeException("process must have neighbors");
        }
        // Each iteration represent a round, Wait until round is finished (all processes completed the round) before starting another one
        // Stop when all rounds are finished
        while (controllerMonitor.waitForNextRound(finishedRound)) {
            int rValue = rightNeighbor.getValue(true); // Get right neighbor value
            int lValue = leftNeighbor.getValue(false); // Get left neighbor value
            // Determine the offset between the process and his neighbors
            if (this.processVal > rValue && this.processVal > lValue) {
                chengeValue = -1;
            } else if (this.processVal < rValue && this.processVal < lValue) {
                chengeValue = 1;
            }
            // we gonna wait until all the process checked the current process value before adding change value
            waitForChecks();
            this.processVal += chengeValue;

            // Notify to the monitor that this process has completed the current round, and prepare for the next one.
            controllerMonitor.processFinishNotify();
            this.finishedRound++;
            this.leftChecked = false;
            this.rightChecked = false;//ready for another round
        }
    }
    // Wait until the value of the process was checked by all neighbors.
    //each process will add his own offset when all the checks are done
    private synchronized void waitForChecks() {
        while (!rightChecked || !leftChecked) {
            try {
                wait();//wait to wake up when checks are over
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    //used by the neighbors to get the process value and specify which neighbor got it.
    //This way the process can keep track if all neighbors checked its value.
    private synchronized int getValue(boolean leftFlag) {
        if (leftFlag) {
            leftChecked = true;
        } else { // If not from left then from right.
            rightChecked = true;
        }
        notifyAll(); // To wake the process when it's waiting for its value to be checked.
        return processVal;
    }
//process and its value
    @Override
    public String toString() {
        return "" + processVal;
    }
}
