import java.util.Random;
import java.util.Scanner;

public class Main {
    final static int MIN_VALUE_RANGE = 0;  // Min value for the process value
    final static int MAX_VALUE_RANGE = 100; // Max value for the process value
    public static void main(String[] args) {
        // Get the amount of processes and rounds from the user.
        int numOfProcesses = 0;
        int numOfRounds = 0;
        Scanner scanner = new Scanner(System.in);
        boolean InValidInput = true;// flag for valid input
        //we will get input from the user until its valid
        while(InValidInput) {
           	try {
        		System.out.print("Please enter how many processes");//only integers
        		numOfProcesses = scanner.nextInt();
        		System.out.print("Please enter how many rounds");//only integers
        		numOfRounds = scanner.nextInt();
        		InValidInput = false;
        	} catch (Exception e) {
        		scanner.next();
        		System.out.println("all input must be integers try again");
        		InValidInput = true;
        	}
    	}
        // Create the Controller monitor to sync the execution of each round.
        ControllerMonitor controllerMonitor = new ControllerMonitor(numOfProcesses, numOfRounds);
        // Create the processes.
        Random rand = new Random();
        Process[] allProcesses = new Process[numOfProcesses];//new array in the size of the number of processes
        for (int i = 0; i < numOfProcesses; i++) {
            int randomNum = MIN_VALUE_RANGE + rand.nextInt(MAX_VALUE_RANGE + 1);//create random number in the range
            allProcesses[i] = new Process(controllerMonitor, randomNum);//create new array with the processes and controller monitor with random number
        }
        // Initialize the processes neighbors
        allProcesses[0].setNeighbors(allProcesses[numOfProcesses - 1], allProcesses[1]);
        for (int i = 1; i < numOfProcesses - 1; i++) {
            allProcesses[i].setNeighbors(allProcesses[i - 1], allProcesses[i + 1]);
        }
        allProcesses[numOfProcesses - 1].setNeighbors(allProcesses[numOfProcesses - 2], allProcesses[0]);
        // Print start state
        System.out.print("start round -> ");
        for(int i = 0; i<allProcesses.length ; i++) {
        	System.out.print(" " + allProcesses[i].toString());
        }
        System.out.println();
        // Start the processes.
        for (int i = 0; i < numOfProcesses; i++) {
            allProcesses[i].start();
        }
        // Print the state after each round
        for (int round = 1; round <= numOfRounds; round++) {
            // wait for the round end before printing 
            controllerMonitor.fullRoundPrintWait();
            System.out.print("round " + round + "->");
            for(int i = 0 ; i<allProcesses.length ; i++) {
            	System.out.print(" " + allProcesses[i].toString());
            }
            System.out.println();
            // Notify the monitor that the printing is done and the next round can begin.
            controllerMonitor.finishPrintNotify();
        }
        scanner.close();//close the scanner
    }
}
