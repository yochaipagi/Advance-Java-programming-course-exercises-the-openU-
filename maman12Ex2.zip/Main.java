import java.util.Scanner;

public class Main {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner scan = new Scanner (System.in);
		Rational[] r = new Rational[2];//will contain the 2 rational numbers		
		for (int i=0;i<2;i++){//create 2 new Rational numbers  {
			boolean flag = true;
			int a=0,b=0,counter = i+1;
			while(flag){
				System.out.println("type number "+counter+":");
				System.out.print("a"+counter+": ");
				try {
					scan = new Scanner (System.in);//empty the scanner after bad inputs
					a = scan.nextInt();
				}
				catch(Exception e){
					System.out.println("numerator must be integer");
					continue;
				}
				System.out.print("b"+counter+": ");
				try {
					scan = new Scanner (System.in);//empty the scanner after bad inputs
					b = scan.nextInt();
				}
				catch(Exception e){
					System.out.println("denominator must be integer");
					continue;
				}
				try {
					flag = !checkValues(a,b);//if the values are invalid
				}
				catch (Exception e) {
					System.out.println(e);
					flag  = true;//scan another numbers
				}
			}
			try {
				r[i] = new Rational(a,b);
			}
			catch (Exception e) {
				System.out.println(e);
				i--;//we need to get another number
			}
		}
		
		if (scan != null) {scan.close();}
		
		//reduce
		System.out.println("reduce:\tr1: "+r[0].toString()+"->"+(r[0].reduce()).toString()+"\n\tr2: "+r[1].toString()+"->"+(r[1].reduce()).toString());
		
		//greaterThan
		System.out.println("if "+(r[0].reduce()).toString()+" > "+(r[1].reduce()).toString()+": "+(r[0].greaterThan(r[1])));
		
		//equals
		System.out.println("if "+(r[0].reduce()).toString()+" = "+(r[1].reduce()).toString()+": "+(r[0].equal(r[1])));
		
		//plus
		System.out.println((r[0].reduce()).toString()+" + "+(r[1].reduce()).toString()+" = "+((r[0].plus(r[1])).reduce()).toString());
		
		//minus
		System.out.println((r[0].reduce()).toString()+" - "+(r[1].reduce()).toString()+" = "+((r[0].minus(r[1])).reduce()).toString());
		//multiply
		System.out.println((r[0].reduce()).toString()+" * "+(r[1].reduce()).toString()+" = "+((r[0].multiply(r[1])).reduce()).toString());
		
		//divide
		System.out.println((r[0].reduce()).toString()+" / "+(r[1].reduce()).toString()+" = "+((r[0].divide(r[1])).reduce()).toString());
				
	}
	public static boolean checkValues(int a , int b) {
		if(b==0 || Math.floor(a) - a != 0) {
			throw new IllegalArgumentException("values are invalid");
		}
		return true;
	}

}
