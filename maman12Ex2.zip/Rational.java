import java.lang.Math;
public class Rational {
	private int nume;//the numerator
	private int deno;//the denominator
	
	public Rational(int nume , int deno) {
		if(deno > 0 && ((int)nume) - nume == 0) {
			this.nume = nume;
			this.deno = deno;
		}
		else {
			throw new IllegalArgumentException("values are invalid!!");
		}
	}
	public int getNume() {
		return this.nume;
	}
	public int getDeno() {
		return this.deno;
	}
	public String toString() {
		return this.nume +"/"+this.deno;
	}
	public boolean greaterThan(Rational num) {
		if(this.nume*num.getDeno() > this.deno*num.getNume()) {//as defined a/b > c/d if ad > bc
			return true;
		}
		else {return false;}
	}
	public boolean equal(Rational num) {
		if(this.nume*num.getDeno() == this.deno*num.getNume()) {//as defined a/b == c/d if ad == bc
			return true;
		}
		else {return false;}
	}
	
	public Rational plus(Rational num) {
		Rational newNum = new Rational((this.nume*num.getDeno()+this.deno*num.getNume()), this.deno*num.getDeno());
		return newNum;
	}
	
	public Rational minus(Rational num) {
		Rational newNum = new Rational((this.nume*num.getDeno()-this.deno*num.getNume()), this.deno*num.getDeno());
		return newNum;
	}
	public Rational multiply(Rational num) {
		Rational newNum = new Rational(this.nume*num.getNume(),this.deno*num.getDeno());
		return newNum;
	}
	public Rational divide(Rational num) {
		if(num.nume == 0) {
			throw new ArithmeticException("you are trying divide be 0!");
		}
		if(num.getNume()<0){//the numerator is negative so we make the new numerator negative in order to keep the denominator positive
			Rational newNum = new Rational (num.getDeno()*(-1) , num.getNume()*(-1));// turn the number for the divide;
			return this.multiply(newNum);// the definition of divide 
		}
		else {
			Rational newNum = new Rational (num.getDeno(), num.getNume());// turn the number for the divide;
			return this.multiply(newNum);// the definition of divide 
		}
	}
	
	public Rational reduce() {
		int GCD = gcd(this.nume,this.deno);//find the GCD
		return new Rational(this.nume/Math.abs(GCD) ,this.deno/Math.abs(GCD));//reduce the rational number we using absolute gcd in order to keep the positive negative of the numbers
	}
	
	static private int gcd(int x, int y)//using the guidance in the book
	{
		if (y == 0) {
			return x;
		}
		return gcd(y, x % y);
	}
	
	

}
