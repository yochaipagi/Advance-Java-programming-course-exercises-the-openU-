import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;

import java.io.File;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class Maman14Ex2Controller implements Initializable {

    @FXML
    private ListView<String> wordsListView;

    @FXML
    private TextArea definitionTextArea;

    @FXML
    private MenuItem saveFileMenuItem;

    @FXML
    private TextField searchTextField;

    @FXML
    private Button editButton;

    @FXML
    private Button saveButton;
    
    @FXML
    private Button deleteButton;

    Dictionary dictionary;

    private String currentSelectedWord;

    // This field holds the last file which we opened or saved as
    private File currentFile;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        dictionary = new Dictionary();//make new dictionary using the tree map logic in the Dictionary class
        wordsListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            String selectedItem = wordsListView.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                editButton.setVisible(true);
                saveButton.setVisible(true);
                deleteButton.setVisible(true);
                editButton.setDisable(false);
                saveButton.setDisable(true);
                definitionTextArea.setEditable(false);
                currentSelectedWord = selectedItem;
                definitionTextArea.setText(dictionary.getWordDefinition(selectedItem));
            }
        });
    }
    //when we prees the new in the menu we will clear the data and the display
    @FXML
    public void onNewMenuItemPressed(ActionEvent e) {
        dictionary.clear();
        wordsListView.getItems().clear();
        definitionTextArea.clear();
        //initializeNodesProperties();
    }
    //when we prees open menu
    @FXML
    public void onOpenMenuItemPressed(ActionEvent e) {
        FileChooser fileChooser = new FileChooser();//new file chooser
        // Set Initial Directory to Desktop
        fileChooser.setInitialDirectory(new File(System.getProperty("user.dir")));
        // Set extension filter, only TXT files will be shown
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt"));

        // Show open file dialog
        File file = fileChooser.showOpenDialog(wordsListView.getScene().getWindow());
        //if the file is valid we will enter all the words using the logic dictionary
        if (file != null) {
            this.currentFile = file;
            saveFileMenuItem.setDisable(true);
            dictionary.loadDictionary(file);
            wordsListView.getItems().clear();//clear all the current dict
            wordsListView.getItems().addAll(dictionary.getAllWords());//enter all the file that we entered
        }
    }
//on save pressed 
    @FXML
    public void onSaveFileMenuItemPressed(ActionEvent e) {
        dictionary.saveDictionary(currentFile);
        saveFileMenuItem.setDisable(true);
    }
//on save as pressed
    @FXML
    public void onSaveAsFileMenuItemPressed(ActionEvent e) {
        FileChooser fileChooser = new FileChooser();
        // Set Initial Directory to Desktop
        fileChooser.setInitialDirectory(new File(System.getProperty("user.dir")));
        fileChooser.setTitle("SaveAs");
        // Set extension filter, only TXT files will be shown
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt"));
        File file = fileChooser.showSaveDialog(wordsListView.getScene().getWindow());
        //if the file is valid we will save it
        if (file != null) {
            this.currentFile = file;
            saveFileMenuItem.setDisable(true);
            dictionary.saveDictionary(file);
        }
    }

    @FXML
    public void onAddMouseClicked(MouseEvent e) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Add new word");
        dialog.setHeaderText("Please enter a word to add");
        boolean validWordFlag = false;//we will gets words till its valid
        while (!validWordFlag) {
            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                String word = result.get().toLowerCase();//save the word to lower case
                if (wordsListView.getItems().contains(word)) {
                    dialog.setHeaderText("'" + word + "'" + " already exists enter a diffrenet one");
                } else {
                	//the word and def is valid we will enter it to the dictionary
                    validWordFlag = true;
                    dialog = new TextInputDialog();
                    dialog.setTitle("Add new word");
                    dialog.setHeaderText("Please enter the definition of the word");
                    result = dialog.showAndWait();//save the def
                    result.ifPresent(definition -> {
                        wordsListView.getItems().add(word);
                        wordsListView.getSelectionModel().select(word);
                        dictionary.setWordDefinition(word, definition);
                        definitionTextArea.setText(definition);
                        if (currentFile != null) {
                            saveFileMenuItem.setDisable(false);
                        }
                    });
                }
            } else {
                break;
            }
        }


    }
    //search in the dictionary
    @FXML
    public void onSearchTextTyped(KeyEvent e) {
        String searchTextInput = searchTextField.getText();//get the word to dearch
        List<String> currentWordsList = dictionary.getAllWords().stream()//we will search in all the words stream
                .filter(key -> key.contains(searchTextInput.toLowerCase())).collect(Collectors.toList());//using filter find the word in the list that contain the wanted word
        wordsListView.getItems().clear();
        wordsListView.getItems().addAll(currentWordsList);
    }
  //edit the dictionary
    @FXML
    public void onEditMouseClicked(MouseEvent e) {
        definitionTextArea.setEditable(true);
        editButton.setDisable(true);
        saveButton.setDisable(false);
    }
  //save the current change
    @FXML
    public void onSaveMouseClicked(MouseEvent e) {
        if (currentFile != null) {
            saveFileMenuItem.setDisable(false);
        }
        dictionary.setWordDefinition(currentSelectedWord, definitionTextArea.getText());
        definitionTextArea.setEditable(false);
        editButton.setDisable(false);
        saveButton.setDisable(true);
    }
    //delete word from the dictioanry
    @FXML
    public void onDeleteMouseClicked(MouseEvent e) {
        if (currentFile != null) {
            saveFileMenuItem.setDisable(false);
        }
        dictionary.removeWord(currentSelectedWord);
        wordsListView.getItems().clear();///clear the dict
        wordsListView.getItems().addAll(dictionary.getAllWords());
        definitionTextArea.clear();//clear the text area
    }

}
