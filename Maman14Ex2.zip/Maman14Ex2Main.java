import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.Objects;

public class Maman14Ex2Main extends Application {

    public static final int SCENE_WIDTH = 640;
    public static final int SCENE_HEIGHT = 400;

    @Override
    public void start(Stage stage) throws Exception {
        VBox root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Maman14Ex2.fxml")));
        Scene scene = new Scene(root, SCENE_WIDTH, SCENE_HEIGHT);
        stage.setTitle("Words Dictionary");
        stage.setScene(scene);
        stage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }

}
