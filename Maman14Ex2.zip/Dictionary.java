import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

//this will be all the dictionary logic
public class Dictionary {


//we will use tree map in order to keep the words sorted
    private final TreeMap<String, String> dictionary;

    public Dictionary() {
        this.dictionary = new TreeMap<>();
    }

    public void clear() {
        dictionary.clear();
    }
    //get all the words
    public Set<String> getAllWords() {
        return dictionary.keySet();
    }
    //get definition
    public String getWordDefinition(String word) {
        return dictionary.get(word);
    }

    public void setWordDefinition(String word, String definition) {
        dictionary.put(word, definition);
    }
    
    public void removeWord(String word) {
        dictionary.remove(word);
    }

//loads dictionary from a file
    @SuppressWarnings("resource")
	public void loadDictionary(File file) {
        clear();
        Scanner scanner;
        try {
            scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String wordDefinition = scanner.nextLine();//get full line into the variable
                String[] wordDefinitionSplit = wordDefinition.split(" - ");//we will split the words with -
                if (wordDefinitionSplit.length != 2) {
                    throw new Exception("File content is not valid");
                }
                dictionary.put(wordDefinitionSplit[0].toLowerCase(), wordDefinitionSplit[1]);// will put into the dictionary 
            }
            scanner.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

//save the dictionary into a file
    public void saveDictionary(File file) {
        try {
            PrintWriter writer = new PrintWriter(file);
            dictionary.forEach((key, value) -> writer.println(key + " - " + value));//for every line in the dictionary we will write it into the file
            writer.close();
        } catch (FileNotFoundException ex) {
            throw new RuntimeException(ex);
        }
    }
}

