
import java.util.Scanner;
import java.util.Vector;

public class Maman15Ex1Main {
	public Maman15Ex1Main() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        int numOfThreads=0;
        int arraySize=0;
        try {
        	System.out.println("enter how many numbers");
        	arraySize = scanner.nextInt();
        	System.out.println("enter how many threads");
        	numOfThreads = scanner.nextInt();
        }catch (NumberFormatException e){
            System.out.println("ERROR: input can be numbers only");
            System.exit(1);
        }
        //we use 1 defalut values for arraySize and number of threads
        if(arraySize<=0){
            arraySize=1; 
        }
        if (numOfThreads<=0){
            numOfThreads=1; 
        }
        //generate arraySize random variables
        Vector<Integer> vec=new Vector<Integer>(arraySize);
        for (int i = 0; i < arraySize; i++) {
            int num=(int)(Math.random()*100);
            vec.add(num);
        }
        //run the threads using the controller
        VectorController controller = new VectorController(numOfThreads,vec);
        printVector(vec);//we will check ourself
        controller.makeThreads();
        //wait for threads to finish.
        controller.waitForThreads();
        if (vec.size()!=1){//if the vector size is not 1 we still not finished
            System.out.println("ERROR, vec size: "+vec.size());
        } else{
        	System.out.println("the sum is "+vec.get(0));//in the end we will have 1 element in the vector it will be the sum
        }
        scanner.close();//close the scanner

    }
	//print the vector elements
	public static void printVector(Vector<Integer> vec) {
		for(int i = 0 ; i<vec.size(); i++) {
			System.out.println(vec.get(i));
		}
	}
}