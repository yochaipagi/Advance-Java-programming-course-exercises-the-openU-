import java.util.Vector;

public class SumThread extends Thread {
	private Vector<Integer> myVector;
	private VectorController myVectorController;
	
	public SumThread(VectorController vectorController) {
		this.myVector = vectorController.getVector();//now we have the original vector
		this.myVectorController = vectorController;
	}
    public void run() {
        int num1,num2;
        //tries taking a number from the vector we use 0 if the vector is empty 
        try {
            num1 = myVector.remove(0);
        } catch (ArrayIndexOutOfBoundsException e) {
            num1=0;
        }
        //if the first number is 0, we can skip this addition and continue
        if (num1!=0) {
            //tries taking a second number from the vector.
            try {
                num2 = myVector.remove(0);
            } catch (ArrayIndexOutOfBoundsException e) {
                //same as before
                num2 = 0;
            }
            int sum = num1 + num2;
            //if the sum is 0 we will skip the adding to the vector
            if (sum != 0) {
                myVector.add(sum);
            }
        }
        myVectorController.threadIsFinished();//the thread will let the vector controller know he had finished his work
    }
}
