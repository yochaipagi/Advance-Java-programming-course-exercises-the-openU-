import java.util.Vector;

public class VectorController {
	private int numOfThreads;
	private int threadCount;
	private Vector <Integer> myVector;

    public VectorController(int num, Vector<Integer> vec) {
        this.numOfThreads = num;
        this.myVector = vec;
        this.threadCount = 0;
    }
    //vector getter
    public Vector<Integer> getVector() {
        return this.myVector;
    }
    //it will alert that a thread finished all his work
    public synchronized void threadIsFinished() {
        this.threadCount--;//one less thread
        this.makeThreads();//check and make new thread if possible
        this.notify();//notify the waitForThreads method the threads had finished
    }
    //wait till the threads number is 0
    public synchronized void waitForThreads() {
        while(this.threadCount > 0) {
            try {
                this.wait();
            } catch (InterruptedException var2) {
                System.out.println("error");
            }
        }

    }
    //make the threads start running while we still have numbers in the vector and we havant reach the maximum number of threads
    public synchronized void makeThreads() {
        while(this.myVector.size() > 1 && this.threadCount < this.numOfThreads) {
            this.threadCount++;
            (new SumThread(this)).start();//thread will start running
        }

    }
}
