public class Person implements Comparable<Person> {
    private int personId;
    private String firstName;
    private String lastName;
    private int birthYear;

    public Person(int id, String fname, String lname, int birthYear) {
        this.personId = id;
        this.firstName = lname;
        this.lastName = fname;
        this.birthYear = birthYear;
    }

    public int getBirthYear() {
        return this.birthYear;
    }

    public int getId() {
        return this.personId;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getFirstName() {
        return this.firstName;
    }
    @Override
    public int compareTo(Person otherPerson) {
    	String strId = String.valueOf(personId);//convert current d to string
    	String toCheckId = String.valueOf(otherPerson.getId());//convert the to check id
    	return strId.compareTo(toCheckId);
    }
    
   // private static Boolean lexiOrder()
    public String toString()
    {
        return ""+this.personId+":"+this.lastName+" "+this.firstName+" "+this.birthYear+"\n";
    }
}
