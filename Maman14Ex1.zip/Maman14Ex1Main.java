import java.util.Scanner;


public class Maman14Ex1Main {
    public static void main(String[] args) {
                bEx();
                cEx();
    }

    public static void bEx () {
    	Scanner nums = new Scanner(System.in);
        Integer[] array_a = new Integer[10];
        Integer[] array_b = new Integer[10];
        Integer[] array_c = new Integer[10];
        //fill the arrays with values
        randArrray(array_a);
        randArrray(array_b);
        randArrray(array_c);
        //crate all the sets
        Set<Integer> setA = new Set<Integer>(array_a);
        Set<Integer> setB = new Set<Integer>(array_b);
        Set<Integer> setC = new Set<Integer>(array_c);
        System.out.println("Set A: " + setA);
        System.out.println("Set B: " + setB);
        System.out.println("Set C: " +setC);
        setA.union(setB);
        System.out.println("setA union with setB is:  " + setA);
        setA.intersect(setC);
        System.out.println("setA intersect with setC is:  " + setA);
        //new sub Ex
        Integer[] userArr = new Integer[2];
        getUserInput(userArr , nums);
        Set<Integer> userSet = new Set<Integer>(userArr);
        if(setA.isSubset(userSet)) {
        	System.out.println("the user Set is subSet of SetA ");
        }
        if(setB.isSubset(userSet)) {
        	System.out.println("the user Set is subSet of SetB ");
        }
        if(setC.isSubset(userSet)) {
        	System.out.println("the user Set is subSet of SetC ");
        }
        //new sub Ex

        System.out.println("please enter another num and see it added and deleted");
        int userNum = nums.nextInt();
        nums.close();
        System.out.println(userNum);
        setB.insert(userNum);//insert to setB
        setC.delete(userNum);//delete from setC	if the number not in setC it wont do a thing
        if(setA.isMember(userNum)) {
        	System.out.println("your number "+ userNum + "is in setA");
        }
        System.out.println(  "New setB is : " + setB + "\n" +  "New setC is : " + setC);
    }

    public static void cEx() {
        Person p1 = new Person(209120336, "gabi", "kanikovski", 2000);
        Person p2 = new Person(209176336, "avi", "rikan", 1997);
        Person p3 = new Person(302120336, "enric", "saborit", 1999);
        Person p4 = new Person(567038467, "stipe", "perica", 1994);
        Person p5 = new Person(209445336, "dan", "biton", 2001);
        Person[] persons = {p1, p2, p3, p4, p5};
        Set<Person> set = new Set<Person>(persons);
        GetMin<Person> min = new GetMin<Person>();
        System.out.println("\nThe minimal member in the group is:\n" + min.Minumum(set));
    }
    //crate random array from 0-100
    public static void randArrray(Integer[] arr) {
        for (int i = 0; i < arr.length; i++)
            arr[i] = (int) (Math.random() * 100);
    }

    public static void getUserInput(Integer[] arr , Scanner nums) {
        System.out.println("Enter 2 numbers with enter between");
        for (int i = 0; i < 2; i++) {
            if (nums.hasNextInt()) {
                arr[i] = nums.nextInt();
            } else {
                System.out.println("we are looking for 2 numbers");
                System.exit(1);
            }
        }
    }
}
