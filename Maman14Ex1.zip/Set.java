
import java.util.ArrayList;
import java.util.Iterator;

public class Set<E> {
    private ArrayList<E> set;
    
    public Set() {
        set = new ArrayList<>();
    }

    public Set(E[] array) {
        set = new ArrayList<E>();
        for (int i = 0; i < array.length; i++) {
            this.insert(array[i]);
        }
    }

    public void union(Set<E> otherSet) {
        for (int i = 0; i < otherSet.set.size(); i++) {//Iterate all the other set and enter the values to the current set
            this.insert(otherSet.set.get(i));
        }
    }
    //keeps only the common of the two sets
    public void intersect(Set<E> other) {
        for (int i = 0; i < this.set.size(); i++) {
        	E tempNode = this.set.get(i);
        	if(!other.isMember(tempNode)){//if the tempNode is not a member in other we delete from the current set
                delete(this.set.get(i));
                i--;//if we delete we can use the same i for the next iteration
            }
        }
    }
    //check if all the values are in the current set
    public boolean isSubset(Set<E> other) {
        for (int i = 0; i < other.set.size(); i++) {
        	E tempNode = other.set.get(i);
            if (!this.isMember(tempNode)) {
                return false;//if we found one member that dont in the group we can return false
            }
        }
        return true;
    }
    
    public boolean isMember(E other) {
    	for(int i = 0 ; i<this.set.size() ; i++) {
    		E tempNode = this.set.get(i);
    		if(tempNode.equals(other)) {
    			return true;//if we found an equal member we will return true
    		}
    	}
    	return false;
    }
    public void insert(E other) {
        if (!this.isMember(other)) {
            set.add(other);
        }
    }	

    public void delete(E other) {
        if (this.isMember(other)) {//if the other is in the set
        	for(int i = 0 ; i<this.set.size() ; i++) {//we will find the index
        		E tempNode = this.set.get(i);
        		if(tempNode.equals(other)) {
        			this.set.remove(i);//we will remove the index
        		}
        	}
        }
    }
    
    public Iterator<E> iterator() {
        return set.iterator();
    }

    public String toString() {

        String str = "";
        for (int i = 0; i < this.set.size(); i++) {
            str += set.get(i).toString() + " ";
        }
        return str;
    }
}
