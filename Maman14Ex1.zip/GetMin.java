import java.util.Iterator;

public class GetMin<E extends Comparable<E>> {
    public E Minumum(Set<E> other) {
        E temp;
        E min = other.iterator().next();//get a member and use it as min
        Iterator<E> itr = other.iterator();//get iterator to iterate the set 
        while (itr.hasNext()) {
            temp = itr.next();
            if (min.compareTo(temp) > 0) {//if min is bigger then temp we use temp as the new min
                min = temp;
            }
        }
        return min;
    }
}
